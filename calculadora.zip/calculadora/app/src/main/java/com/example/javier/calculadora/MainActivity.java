package com.example.javier.calculadora;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btnms,btnme,btndi,btnmu,btnpu,btnli,btnig;
    TextView con;
    double numero1=0,numero2=0,res=0;
    String operacion="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnig = (Button) findViewById(R.id.btnig);
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btnms = (Button) findViewById(R.id.btnms);
        btnme = (Button) findViewById(R.id.btnme);
        btndi = (Button) findViewById(R.id.btndi);
        btnmu = (Button) findViewById(R.id.btnmu);
        btnpu = (Button) findViewById(R.id.btnpu);
        btnli = (Button) findViewById(R.id.btnli);
        con = (TextView) findViewById(R.id.con);
        btn0.setOnClickListener(new View.OnClickListener() {
                             @Override
                             public void onClick(View view) {
                                 con.setText(con.getText().toString() + "0");
                             }
                         }

        );
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText(con.getText().toString() + "9");
            }
        });
        btnms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (con.getText().toString().equals(""))
                {


                }else{
                    operacion="+";
                    numero1=Double.parseDouble(con.getText().toString());
                    con.setText("");
                }
            }
        });
        btnme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (con.getText().toString().equals(""))
                {


                }else{
                    operacion="-";
                    numero1=Double.parseDouble(con.getText().toString());
                    con.setText("");
                }

            }
        });
        btndi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (con.getText().toString().equals(""))
                {


                }else{
                    operacion="/";
                    numero1=Double.parseDouble(con.getText().toString());
                    con.setText("");
                }
            }
        });
        btnpu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int punto= con.getText().toString().indexOf(".");


                if (punto == -1)
                {
                    con.setText(con.getText().toString() + ".");
                }else{

                }

            }
        });
        btnig.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    numero2=Double.parseDouble(con.getText().toString());
                    con.setText("");


                        if (operacion.equals("+")) {
                            res = numero1 + numero2;
                        }
                        if (operacion.equals("-")) {
                            res = numero1 - numero2;
                        }
                        if (operacion.equals("x")) {
                            res = numero1 * numero2;
                        }
                        if (operacion.equals("/")) {
                            res = numero1 / numero2;
                        }
                        con.setText(String.valueOf(res));

                }catch (Exception e){
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(MainActivity.this);
                    //seleccionamos la cadena a mostrar
                    dialogBuilder.setMessage("No se puede hacer operacion sin al menos dos valor");
                    //elegimo un titulo y configuramos para que se pueda quitar
                    dialogBuilder.setCancelable(true).setTitle("Error!!");
                    //mostramos el dialogBuilder
                    dialogBuilder.create().show();
                    }

            }
        });
        btnmu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (con.getText().toString().equals(""))
                {


                }else{
                    operacion="x";
                    numero1=Double.parseDouble(con.getText().toString());
                    con.setText("");
                }
            }
        });
        btnli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                con.setText("");
                numero1=0;
                numero2=0;
                res=0;
            }
        });
    }

}
